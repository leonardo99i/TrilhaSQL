# SQL

![Untitled](SQL%20cdbd8c32bc994be98782ab50e87eaca3/Untitled.png)

## OR:

- Se uma das expressões for verdadeira a expressão completa será verdadeira.
    - Exemplos:
    - (V) OR (V) → Verdadeiro
    - (V) OR (F) → Verdadeiro
    - (F) OR (V) → Verdadeiro
    - (F) OR (F) → Falso

## AND:

- Se todas as expressões forem verdadeiras a expressão completa será verdadeira.
    - Exemplos:
    - (V) AND (V) → Verdadeiro
    - (V) AND (F) → Falso
    - (F) AND (V) → Falso
    - (F) AND (F) → Falso

![Untitled](SQL%20cdbd8c32bc994be98782ab50e87eaca3/Untitled%201.png)

Se a expressão for verdadeira, com o NOT colocado na frente ele vira falsa.

Se a expressão for falsa, com o NOT colocado na frente ele vira verdadeiro.